Bible_of_k = {
    'SPRITE': 90,
    'COLA': 100,
    'WATER': 10
}
